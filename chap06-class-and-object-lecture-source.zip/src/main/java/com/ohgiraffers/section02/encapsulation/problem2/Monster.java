package com.ohgiraffers.section02.encapsulation.problem2;

public class Monster {

//    String name; --> 원래
//    int hp;

    String kinds;   // --> 수정, 에러남
    int hp;


}
